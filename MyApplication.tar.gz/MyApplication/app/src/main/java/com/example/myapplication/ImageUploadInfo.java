package com.example.myapplication;

public class ImageUploadInfo {
    public String imageName;

    public String imageURL;

    public String email;
    public ImageUploadInfo() {

    }

    public ImageUploadInfo(String name, String url) {

        this.imageName = name;

        this.imageURL= url;

        this.email=email;
    }
    public  String email(){ return  email;}

    public String getImageName() {
        return imageName;
    }

    public String getImageURL() {
        return imageURL;
    }
}
